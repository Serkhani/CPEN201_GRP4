-- Customer Profile Table


CREATE TABLE customer_profile (
  id serial PRIMARY KEY,
  name text NOT NULL,
  address text NOT NULL,
  phone_number text NOT NULL,
  email text NOT NULL,
  payment_method text NOT NULL
);

-- Fuel Tank Table 
-- This table will store information about each fuel tank.

CREATE TABLE fuel_tank (
  id serial PRIMARY KEY,
  name text NOT NULL,
  capacity numeric NOT NULL,
  current_level numeric NOT NULL
);

-- Fuel Transaction Table
-- This table will store information about each fuel transaction.

CREATE TABLE fuel_transaction (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL,
  employee_id integer NOT NULL,
  date_time timestamp NOT NULL,
  amount_purchased numeric NOT NULL,
  pump_id integer NOT NULL
);

-- Product Table
-- This table will store information about each product sold at the filling station.


CREATE TABLE product (
  id serial PRIMARY KEY,
  name text NOT NULL,
  price numeric NOT NULL,
  quantity_on_hand numeric NOT NULL
);

-- Product Transaction Table
-- This table will store information about each product transaction.


CREATE TABLE product_transaction (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL,
  employee_id integer NOT NULL,
  date_time timestamp NOT NULL,
  amount_purchased numeric NOT NULL,
  product_id integer NOT NULL
);

-- Employee Table
CREATE TABLE employee (
  id serial PRIMARY KEY,
  name text NOT NULL,
  email text NOT NULL,
  phone_number text NOT NULL,
  job_title text NOT NULL,
  hire_date date NOT NULL,
  salary numeric NOT NULL
);
CREATE TABLE employee_log (
  id serial PRIMARY KEY,
  employee_id integer NOT NULL,
  action text NOT NULL,
  date_time timestamp NOT NULL
);


-- INSERTS
-- Customer Profile Table
INSERT INTO customer_profile (name, address, phone_number, email, payment_method) VALUES
  ('John Doe', '123 Main Street', '555-555-5555', 'johndoe@example.com', 'cash'),
  ('Jane Doe', '456 Elm Street', '666-666-6666', 'janedoe@example.com', 'credit card'),
  ('Bill Smith', '789 Oak Street', '777-777-7777', 'billsmith@example.com', 'mobile payment'),
  ('Sally Jones', '1010 Pine Street', '888-888-8888', 'sallyjones@example.com', 'cash'),
  ('Peter Parker', '2020 Maple Street', '999-999-9999', 'peterparker@example.com', 'credit card');

-- Fuel Tank Table
INSERT INTO fuel_tank (name, capacity, current_level) VALUES
  ('Tank 1', 1000, 800),
  ('Tank 2', 2000, 1500),
  ('Tank 3', 3000, 2200),
  ('Tank 4', 4000, 3000),
  ('Tank 5', 5000, 4000);

-- Fuel Transaction Table
INSERT INTO fuel_transaction (customer_id, employee_id, date_time, amount_purchased, pump_id) VALUES
  (1, 1, '2023-05-19 14:00:00', 10.00, 1),
  (2, 2, '2023-05-19 14:15:00', 15.00, 2),
  (3, 3, '2023-05-19 14:30:00', 20.00, 3),
  (4, 4, '2023-05-19 14:45:00', 25.00, 4),
  (5, 5, '2023-05-19 15:00:00', 30.00, 5);

-- Product Table
INSERT INTO product (name, price, quantity_on_hand) VALUES
  ('Snacks', 1.00, 100),
  ('Coffee', 2.00, 90),
  ('Soda', 1.50, 80),
  ('Water', 0.50, 70),
  ('Gum', 0.50, 60);

-- Product Transaction Table
INSERT INTO product_transaction (customer_id, employee_id, date_time, amount_purchased, product_id) VALUES
(1, 1, '2023-05-19 14:00:00', 1, 1),
(2, 2, '2023-05-19 14:15:00', 2, 2),
(3, 3, '2023-05-19 14:30:00', 3, 3),
(4, 4, '2023-05-19 14:45:00', 4, 4),
(5, 5, '2023-05-19 15:00:00', 5, 5);

-- Employee Table
INSERT INTO employee (name, email, phone_number, job_title, hire_date, salary)
VALUES ('Ama Atta', 'ama.atta@email.com', '123-456-7890', 'Cleaner', '2023-01-01', 100000),
('Janis Peasah', 'jane.peasah@email.com', '987-654-3210', 'Marketing Manager', '2023-02-01', 80000),
('Mary Akunnnor', 'mary.ak@email.com', '543-210-9876', 'Sales Representative', '2023-03-01', 60000),
('Peter Edward', 'peter.ed@email.com', '765-432-1098', 'Cashier', '2023-04-01', 40000),
('John Brown', 'john.brown@email.com', '321-098-7654', 'Manager', '2023-05-01', 120000);

-- Employee Inserts
INSERT INTO employee_log (employee_id, action, date_time)
VALUES (1, 'insert', '2023-05-19 15:30:00'),
 (2, 'insert', '2023-05-19 15:30:01'),
 (3, 'insert', '2023-05-19 15:30:02'),
 (4, 'insert', '2023-05-19 15:30:03'),
 (5, 'insert', '2023-05-19 15:30:04');



-- This query will return all customers and their contact information, along with the product transactions that they have placed. The results will be ordered by customer name.
-- This is meant to get the customers history for receipts
SELECT customer_profile.name, customer_profile.address, customer_profile.phone_number, product_transaction.product_name, product_transaction.amount_purchased
FROM customer_profile
JOIN product_transaction ON customer_profile.id = product_transaction.customer_id;



-- This query will return all of the products in the database along with information about the orders that each product has been included in. 
SELECT product.name, product.price, product.quantity_on_hand,
       transaction.customer_id, transaction.employee_id,
       transaction.date_time, transaction.total_amount, transaction.products
FROM product
JOIN product_transaction ON product.id = product_transaction.product_id
JOIN transaction ON product_transaction.transaction_id = transaction.id;

-- update fuel tank after every fuel transaction
CREATE TRIGGER update_fuel_tank_trigger
AFTER INSERT OR UPDATE ON fuel_transaction
FOR EACH ROW
BEGIN

-- Get the fuel tank ID from the fuel transaction.
SELECT fuel_tank_id
FROM fuel_transaction
WHERE id = NEW.id;

-- Get the amount of fuel that was purchased.
SELECT amount_purchased
FROM fuel_transaction
WHERE id = NEW.id;

-- Update the fuel level in the fuel tank.
UPDATE fuel_tank
SET current_level = current_level - NEW.amount_purchased
WHERE id = NEW.fuel_tank_id;

END;

CREATE OR REPLACE FUNCTION update_fuel_tank_function()
RETURNS trigger AS
$func$
BEGIN

-- Get the fuel tank ID from the fuel transaction.
SELECT fuel_tank_id
FROM fuel_transaction
WHERE id = NEW.id;

-- Get the amount of fuel that was purchased.
SELECT amount_purchased
FROM fuel_transaction
WHERE id = NEW.id;

-- Update the fuel level in the fuel tank.
UPDATE fuel_tank
SET current_level = current_level - NEW.amount_purchased
WHERE id = NEW.fuel_tank_id;

RETURN NEW;

END
$func$ LANGUAGE plpgsql;




-- This transaction ensures that the fuel level in the fuel tank will only be updated by the current transaction. 
BEGIN TRANSACTION;

-- Acquire an exclusive lock on the fuel tank table.
-- This prevents other users from updating the fuel level in the fuel tank while the transaction is in progress.
LOCK TABLE fuel_tank IN EXCLUSIVE MODE;

-- Get the amount of fuel that was purchased.
SELECT amount_purchased
FROM fuel_transaction
WHERE id = 1;

-- Update the fuel tank table.
UPDATE fuel_tank
SET current_level = current_level - NEW.amount_purchased
WHERE id = NEW.fuel_tank_id;

-- Commit the transaction.
COMMIT TRANSACTION;





-- This trigger will update the quantity of the product in the product table by decreasing it by the quantity purchased in the product transaction
CREATE TRIGGER update_product_trigger
AFTER INSERT OR UPDATE ON product_transaction
FOR EACH ROW
BEGIN

-- Get the product ID from the product transaction.
SELECT product_id
FROM product_transaction
WHERE id = NEW.id;

-- Get the quantity of the product that was purchased.
SELECT quantity
FROM product_transaction
WHERE id = NEW.id;

-- Update the quantity of the product in the product table.
UPDATE product
SET quantity = quantity - NEW.quantity
WHERE id = NEW.product_id;

END;

CREATE OR REPLACE FUNCTION update_product_function()
RETURNS trigger AS
$func$
BEGIN

-- Get the product ID from the product transaction.
SELECT product_id
FROM product_transaction
WHERE id = NEW.id;

-- Get the quantity of the product that was purchased.
SELECT quantity
FROM product_transaction
WHERE id = NEW.id;

-- Update the quantity of the product in the product table.
UPDATE product
SET quantity = quantity - NEW.quantity
WHERE id = NEW.product_id;

RETURN NEW;

END
$func$ LANGUAGE plpgsql;


-- This is to update the price of products
CREATE OR REPLACE FUNCTION update_product_price()
RETURNS trigger AS
$func$
DECLARE
  -- Get the new product price.
  new_price numeric;

BEGIN
  -- Get the new product price from the trigger context.
  new_price := NEW.price;

  -- Update the product price in the products table.
  UPDATE products
  SET price = new_price
  WHERE id = NEW.id;

  -- Return the new product price.
  RETURN NEW;
END
$func$ LANGUAGE plpgsql;

CREATE TRIGGER update_product_price_trigger
AFTER INSERT OR UPDATE ON products
FOR EACH ROW
EXECUTE PROCEDURE update_product_price();
